<?php 
include "config.php"; 
 include DBAPI;

try {
    $db = open_database();

} catch (Exception $e) {
    echo "<h3> Aconteceu um erro: <br>" . $e->getMessage() . "</h3>\n";
}

if ($db) {
    echo "<h1>Banco de Dados Conectado!</h1>";
} else {
    echo "<h1>ERRO: Não foi possível Conectar!</h1>";
}
?>
