function alterarIdEClasse() {

    document.getElementById("meuId").innerHTML = "Mudar ID";


    var elementosDestaqueVermelho = document.getElementsByClassName("destaque-vermelho");
    for (var i = 0; i < elementosDestaqueVermelho.length; i++) {
        elementosDestaqueVermelho[i].innerHTML = "Oi Emerson";
    }
}

function alterarTag() {

    var elementosTorta = document.querySelectorAll(".torta");
    for (var i = 0; i < elementosTorta.length; i++) {
        elementosTorta[i].outerHTML = "<div class='torta'>Muito bom</div>";
    }
}

function alterarEstilo() {

    var elementosDestaqueVermelho = document.querySelectorAll(".destaque-vermelho");
    for (var i = 0; i < elementosDestaqueVermelho.length; i++) {
        elementosDestaqueVermelho[i].style.color = "red";
        elementosDestaqueVermelho[i].style.fontWeight = "bold";
    }


    var elementosTorta = document.querySelectorAll(".torta");
    for (var i = 0; i < elementosTorta.length && i < 2; i++) {
        elementosTorta[i].style.color = "blue";
    }
}
